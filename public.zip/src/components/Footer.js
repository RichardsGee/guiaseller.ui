// src/components/Footer.js
import React from 'react';

function Footer() {
  return (
    <footer>
      <p>&copy; 2024 ESCALLA AI. Todos os direitos reservados.</p>
    </footer>
  );
}

export default Footer;
