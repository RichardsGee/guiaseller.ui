import React from 'react';
import Header from '../components/Header';
import Sidebar from '../components/Sidebar';
import TopBar from '../components/TopBar';
import ToolsList from '../components/ToolsList'; // Componente que lista as ferramentas
import Footer from '../components/Footer';
import { AuthContext } from '../context/AuthContext';
import { useContext } from 'react';

function ToolsPage() {
  const { user, signOut } = useContext(AuthContext);
  const username = user ? user.displayName || user.email : "No User Logged";
  const userPhoto = user ? user.photoURL : null;
  const userEmail = user ? user.email : null;

  return (
    <div className="container">
      <Header username={username} logout={signOut} />
      <Sidebar userPhoto={userPhoto} username={username} userEmail={userEmail} />
      <div className="main-content">
        <TopBar userPhoto={userPhoto} />
        <div className="tools-content">
          <h1>Ferramentas IA</h1>
          <ToolsList /> {/* Componente que vai listar as ferramentas de IA */}
        </div>
      </div>
      <Footer />
    </div>
  );
}

export default ToolsPage;
