export const salesData = [
  { date: '2024-09-01', faturamento: 30000, vendas: 80, lucro: 10000, publicidade: 2000 },
  { date: '2024-09-15', faturamento: 45000, vendas: 100, lucro: 15000, publicidade: 3000 },
  { date: '2024-09-25', faturamento: 50000, vendas: 120, lucro: 20000, publicidade: 4000 },
  { date: '2024-09-28', faturamento: 55000, vendas: 140, lucro: 25000, publicidade: 5000 },
  { date: '2024-10-01', faturamento: 60000, vendas: 160, lucro: 30000, publicidade: 6000 },
];